//
//  HomeViewController.swift
//  PhycomincTest
//
//  Created by Rohit on 04/05/24.
//

import UIKit

class HomeViewController: UIViewController {

    // MARK: - IBOutlet's
    @IBOutlet weak var lbl_wecome: UILabel!
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let displayName = UserDefaults.standard.string(forKey: "displayName") {
            self.lbl_wecome.text = "Welcome, " + displayName
        } else {
            print("Username not found in UserDefaults")
        }
    }

}
