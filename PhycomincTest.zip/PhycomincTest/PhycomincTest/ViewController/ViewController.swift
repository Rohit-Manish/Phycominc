//
//  ViewController.swift
//  PhycomincTest
//
//  Created by Rohit on 03/05/24.
//

import UIKit
import FirebaseCore
import FirebaseAuth
import GoogleSignIn

class ViewController: UIViewController {
    
    // MARK: - IBOutlet's
    @IBOutlet weak var btn_login: GIDSignInButton! {
        didSet {
            self.btn_login.layer.cornerRadius = 5
        }
    }
    
    // MARK: - Variable's
    var modelArticle : [Articles] = []
    var objUtils = Utils()
    
    // MARK: - Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    // MARK: - IBAction's
    @IBAction func loginbutton_ClickedEven(_ sender: UIButton) {
        self.objUtils.googleSignIn(ViewController: self) { isSignIn in
            if isSignIn {
                let mainStoryBoard: UIStoryboard = UIStoryboard(name: Constant.StoryboardIdentifier.main, bundle: nil)
                let homeVC = mainStoryBoard.instantiateViewController(withIdentifier: Constant.ViewControllerIdentifiers.tabBarVC) as! TabBarViewController
                UIApplication.shared.windows.first?.rootViewController = homeVC
            }
        }
        
    }
    
}
