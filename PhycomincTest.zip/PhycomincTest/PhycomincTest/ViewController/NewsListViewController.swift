//
//  NewsListViewController.swift
//  PhycomincTest
//
//  Created by Rohit on 04/05/24.
//

import UIKit
import CoreData

class NewsListViewController: UIViewController {

    // MARK: - IBOutlet's
    @IBOutlet weak var tblView: UITableView!
    
    // MARK: - Variable's
    var objArticles: [Articles] = []
    var objNewData : [NewsData] = []
    
    var arrObj : [Articles] = []
    var objUtils = Utils()
    var articleCoreData = [NSManagedObject]()
    var isGetData = false
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = Constant.NavigationTitle.newsList
        self.tableConfiguration()
        
        fetchNewsData { result in
            switch result {
            case .success(let newsData):
                if let articles = newsData.articles {
                    self.objArticles.append(contentsOf: articles)
                    self.arrObj.append(contentsOf: articles)
                    self.createData()
                    DispatchQueue.main.async {
                        self.tblView.reloadData()
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
        
        self.retrieveData()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Custom Methods
    func goToNewsDetails() {
        let mainStoryBoard: UIStoryboard = UIStoryboard(name: Constant.StoryboardIdentifier.main, bundle: nil)
        let updateProfileVC = mainStoryBoard.instantiateViewController(withIdentifier: Constant.ViewControllerIdentifiers.newsListVC) as? NewsListViewController
         self.navigationController?.pushViewController(updateProfileVC!, animated: true)
    }
    
    func tableConfiguration() {
        self.tblView.delegate = self
        self.tblView.dataSource = self
        self.tblView.separatorStyle = .none
        self.tblView.register(UINib(nibName: Constant.CellIdentifiers.newsCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifiers.newsCell)
    }

    func fetchNewsData(completion: @escaping (Result<NewsData, Error>) -> Void) {
        let urlString = Constant.Key.url + Constant.Key.API_KEY
        print("URL String : \(urlString)")
        guard let url = URL(string: urlString) else {
            completion(.failure(NSError(domain: "Invalid URL", code: 0, userInfo: nil)))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(NSError(domain: "No data", code: 0, userInfo: nil)))
                return
            }

            do {
                let decoder = JSONDecoder()
                let newsData = try decoder.decode(NewsData.self, from: data)
                print("Response : \(newsData)")
                completion(.success(newsData))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
    
    func createData() {
        let managedContext = AppDelegate.shared.persistentContainer.viewContext
        let userEntity = NSEntityDescription.entity(forEntityName: "News", in: managedContext)!
        
        for i in 1..<arrObj.count {
            let user = NSManagedObject(entity: userEntity, insertInto: managedContext)
            user.setValue(self.arrObj[i].author ?? "", forKeyPath: "author")
            user.setValue(self.arrObj[i].title ?? "", forKey: "title")
            user.setValue(self.arrObj[i].publishedAt ?? "", forKey: "publishedAt")
            user.setValue(self.arrObj[i].url ?? "", forKey: "url")
            user.setValue(self.arrObj[i].urlToImage ?? "", forKey: "urlToImage")
            self.articleCoreData.append(user)
            self.isGetData = true
        }

        do {
            try managedContext.save()
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    func retrieveData() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "News")
        
        do {
            let result = try managedContext.fetch(fetchRequest)
            for data in result as! [NSManagedObject] {
                print(data.value(forKey: "title") ?? "")
                print(data.value(forKey: "author") ?? "")
                print(data.value(forKey: "publishedAt") ?? "")
                print(data.value(forKey: "url") ?? "")
                print(data.value(forKey: "urlToImage") ?? "")
                self.articleCoreData = result as! [NSManagedObject]
                self.isGetData = true
            }
        } catch {
            print("Failed")
        }
    }
}

// MARK: - Tableview Deatasource and Delegate
extension NewsListViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isGetData ? articleCoreData.count : arrObj.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifiers.newsCell) as! NewsCell
        
        cell.selectionStyle = .none
        
        if isGetData == true {
            let ariticle = articleCoreData[indexPath.row]
            cell.lbl_title.text = ariticle.value(forKey: "title") as? String
            cell.lbl_author.text = ariticle.value(forKey: "author") as? String
            
            let dateStringFromDatabase = ariticle.value(forKey: "publishedAt") as? String ?? ""
            let formattedDate = Utils.sharedUtils.formatDatabaseDateString(dateStringFromDatabase)
            cell.lbl_date.text = formattedDate
            
            if let url = URL(string: ariticle.value(forKey: "urlToImage") as? String ?? "") {
                cell.img.sd_setImage(with: url, completed: nil)
            } else {
                cell.img.image = UIImage(named: "NoImage")
            }
        } else {
            let data = self.objArticles[indexPath.row]
            cell.configuration(data: data)
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let mainStoryBoard: UIStoryboard = UIStoryboard(name: Constant.StoryboardIdentifier.main, bundle: nil)
        let newsDetailsVC = mainStoryBoard.instantiateViewController(withIdentifier: Constant.ViewControllerIdentifiers.newsDetailVC) as! NewsDetailViewController
        
        if self.isGetData == true {
            let selectedArticle = self.articleCoreData[indexPath.row]
            newsDetailsVC.author = selectedArticle.value(forKey: "author") as? String ?? ""
            newsDetailsVC.titles = selectedArticle.value(forKey: "title") as? String ?? ""
            newsDetailsVC.publishedAt = selectedArticle.value(forKey: "publishedAt") as? String ?? ""
            newsDetailsVC.url = selectedArticle.value(forKey: "url") as? String ?? ""
            newsDetailsVC.photoUrl = selectedArticle.value(forKey: "urlToImage") as? String ?? ""
        } else {
            let selectedArticle = self.arrObj[indexPath.row]
            newsDetailsVC.author = selectedArticle.author ?? ""
            newsDetailsVC.titles = selectedArticle.title ?? ""
            newsDetailsVC.publishedAt = selectedArticle.publishedAt ?? ""
            newsDetailsVC.photoUrl = selectedArticle.urlToImage ?? ""
        }
        
        self.navigationController?.pushViewController(newsDetailsVC, animated: true)
    }
    
}
