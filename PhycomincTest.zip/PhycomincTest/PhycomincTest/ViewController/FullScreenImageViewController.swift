//
//  FullScreenImageViewController.swift
//  PhycomincTest
//
//  Created by Rohit on 05/05/24.
//

import UIKit
import SDWebImage

class FullScreenImageViewController: UIViewController {

    //MARK: - IBOutlet
    @IBOutlet weak var img_fullScreen: UIImageView!
    @IBOutlet weak var btn_dismiss: UIButton!
    
    //MARK: - Variable's
    var imgUrl : String = ""
    
    //MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        if let url = URL(string: self.imgUrl) {
            self.img_fullScreen.sd_setImage(with: url, completed: nil)
        } else {
            self.img_fullScreen.image = UIImage(named: "NoImage")
        }
    }
    
    //MARK: - IBAction
    @IBAction func DismissEventClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
}
