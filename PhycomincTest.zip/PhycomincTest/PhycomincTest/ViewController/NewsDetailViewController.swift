//
//  NewsDetailViewController.swift
//  PhycomincTest
//
//  Created by Rohit on 04/05/24.
//

import UIKit
import SDWebImage
import Network

class NewsDetailViewController: UIViewController {

    // MARK: - IBOutlet's
    @IBOutlet weak var img: UIImageView! {
        didSet {
            self.img.layer.cornerRadius = 5
            self.img.layer.borderWidth = 0.5
            self.img.layer.borderColor = UIColor.black.cgColor
            self.img.contentMode = .scaleToFill
        }
    }
    @IBOutlet weak var lbl_author: UILabel!
    @IBOutlet weak var lbl_title: UILabel!
    @IBOutlet weak var lbl_date: UILabel!
    @IBOutlet weak var btn_url: UIButton!
    @IBOutlet var scrollView: UIScrollView!
    
    // MARK: - Variable's
    var author : String = ""
    var titles : String = ""
    var publishedAt : String = ""
    var url : String = ""
    var photoUrl : String = ""
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if #available(iOS 11.0, *) {
            scrollView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        
        self.navigationItem.title = Constant.NavigationTitle.newsDetail
        self.navigationController?.navigationBar.isTranslucent = true
//        if let navBarHeight = navigationController?.navigationBar.frame.height {
//            scrollView.contentInset.top = navBarHeight
//        }
        
        if let superviewHeight = scrollView.superview?.frame.height {
            scrollView.contentInset.top = superviewHeight
        }
        
        self.setDetailViewData()
        
        // MARK: - Full Screen Image
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
        self.img.addGestureRecognizer(tapGesture)
        self.img.isUserInteractionEnabled = true
    }
    
    // MARK: - IBAction
    @IBAction func UrlClickedEvent(_ sender: UIButton) {
        let mainStoryBoard: UIStoryboard = UIStoryboard(name: Constant.StoryboardIdentifier.main, bundle: nil)
        let WKWebVC = mainStoryBoard.instantiateViewController(withIdentifier: Constant.ViewControllerIdentifiers.WKWebVC) as! WKWebViewController
        WKWebVC.webViewUrl = self.url
        self.navigationController?.pushViewController(WKWebVC, animated: true)
    }
    
    @objc func imageTapped() {
        guard let fullScreenImageViewController = storyboard?.instantiateViewController(withIdentifier: Constant.ViewControllerIdentifiers.fullScreenImageVC) as? FullScreenImageViewController else {
            return
        }
        fullScreenImageViewController.imgUrl = self.photoUrl
        present(fullScreenImageViewController, animated: true, completion: nil)
    }
    
    // MARK: - Custom Method's
    func setDetailViewData() {
        
        let dateStringFromDatabase = self.publishedAt
        let formattedDate = Utils.sharedUtils.formatDatabaseDateString(dateStringFromDatabase)
        
        if let url = URL(string: self.photoUrl) {
            self.img.sd_setImage(with: url, completed: nil)
        } else {
            self.img.image = UIImage(named: "NoImage")
        }
        self.lbl_author.text = self.author
        self.lbl_title.text = self.titles
        self.lbl_date.text = formattedDate
        DispatchQueue.global().async {
            DispatchQueue.main.async {
                self.btn_url.setTitle(self.url, for: .normal)
            }
        }
    }
    
}
