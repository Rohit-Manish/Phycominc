//
//  WKWebViewController.swift
//  PhycomincTest
//
//  Created by Rohit on 05/05/24.
//

import UIKit
import WebKit

class WKWebViewController: UIViewController, WKNavigationDelegate {
    
    // MARK: - Variable's
    var webView: WKWebView!
    var webViewUrl : String = ""
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = Constant.NavigationTitle.webView
        
        self.webView = WKWebView()
        self.webView.navigationDelegate = self
        view = self.webView
        
        let url = URL(string: webViewUrl)!
        self.webView.load(URLRequest(url: url))
        self.webView.allowsBackForwardNavigationGestures = true
    }
    
}
