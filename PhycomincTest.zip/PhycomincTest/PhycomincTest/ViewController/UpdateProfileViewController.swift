//
//  UpdateProfileViewController.swift
//  PhycomincTest
//
//  Created by Rohit on 04/05/24.
//

import UIKit
import SDWebImage
import FirebaseAuth

class UpdateProfileViewController: UIViewController, ImagePickerDelegate {
    
    // MARK: - IBOutlet's
    @IBOutlet weak var img_photoUrl: UIImageView! {
        didSet {
            self.img_photoUrl.layer.borderWidth = 0.5
            self.img_photoUrl.layer.borderColor = UIColor.gray.cgColor
            self.img_photoUrl.layer.cornerRadius = 5
            self.img_photoUrl.contentMode = .scaleToFill
        }
    }
    @IBOutlet weak var txt_displayName: UITextField!
    @IBOutlet weak var txt_email: UITextField!
    @IBOutlet weak var btn_upload: UIButton! {
        didSet {
            self.btn_upload.layer.cornerRadius = 5
        }
    }
    @IBOutlet weak var btn_update: UIButton! {
        didSet {
            self.btn_update.layer.cornerRadius = 5
        }
    }
    
    // MARK: - Variable's
    let imagePicker = UIImagePickerController()

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.imagePicker.delegate = self
        self.getUserDetails()
    }
    
    // MARK: - IBAction's
    @IBAction func uploadClickedEvent(_ sender: UIButton) {
        self.presentImagePicker()
    }
    
    @IBAction func updateClickedEvent(_ sender: UIButton) {
        self.updateUserData()
    }
    
    // MARK: - Method's
    func getUserDetails() {
        if let url = URL(string: Utils.sharedUtils.userDefault.string(forKey: "photoURL") ?? "") {
            self.img_photoUrl.sd_setImage(with: url, completed: nil)
        } else {
            self.img_photoUrl.image = UIImage(named: "NoImage")
        }
        
        self.txt_email.text = Utils.sharedUtils.userDefault.string(forKey: "userName")
        self.txt_displayName.text = Utils.sharedUtils.userDefault.string(forKey: "displayName")
    }
    
    // MARK: - ImagePickerDelegate
    func imagePicker(_ imagePicker: ImagePicker, didSelect image: UIImage) {
        self.img_photoUrl.image = image
    }
    
    func cancelButtonDidClick(on imagePicker: ImagePicker) {
        print("Image selection/capture was canceled")
    }

    func updateUserData() {
        let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
        changeRequest?.displayName = self.txt_displayName.text
        changeRequest?.commitChanges { error in
            Utils.sharedUtils.userDefault.set(self.txt_displayName.text, forKey: "displayName")
            print("Success Commit")
            self.navigationController?.popViewController(animated: true)
        }
    }
}

// MARK: - TextField Delegate
extension UpdateProfileViewController : UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == self.txt_email {
            self.txt_email.resignFirstResponder()
            self.txt_displayName.becomeFirstResponder()
        } else {
            self.txt_displayName.resignFirstResponder()
        }
        return true
    }
}

// MARK: ImagePicker Delegate
extension UpdateProfileViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    private func presentImagePicker() {
        let alertController = UIAlertController(title: "Choose Image Source", message: nil, preferredStyle: .actionSheet)

        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let cameraAction = UIAlertAction(title: "Camera", style: .default) { _ in
                self.showImagePicker(sourceType: .camera)
            }
            alertController.addAction(cameraAction)
        }

        let photoLibraryAction = UIAlertAction(title: "Photo Library", style: .default) { _ in
            self.showImagePicker(sourceType: .photoLibrary)
        }
        alertController.addAction(photoLibraryAction)

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)

        present(alertController, animated: true, completion: nil)
    }

    private func showImagePicker(sourceType: UIImagePickerController.SourceType) {
        imagePicker.delegate = self
        imagePicker.sourceType = sourceType
        present(imagePicker, animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            self.img_photoUrl.image = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}


