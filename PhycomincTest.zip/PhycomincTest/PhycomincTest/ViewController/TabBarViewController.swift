//
//  TabBarViewController.swift
//  PhycomincTest
//
//  Created by Rohit on 04/05/24.
//

import UIKit

class TabBarViewController: UITabBarController {

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - Custom Method's
    func configureTabs() {
//        let homeVC = HomeViewController()
//        let newsVC = NewsListViewController()
//        let profileVC = ProfileViewController()
//        
//        let navHomeVC = UINavigationController.init(rootViewController: homeVC)
//        let navNewsVC = UINavigationController.init(rootViewController: newsVC)
//        let navProfileVC = UINavigationController.init(rootViewController: profileVC)
    }
}
