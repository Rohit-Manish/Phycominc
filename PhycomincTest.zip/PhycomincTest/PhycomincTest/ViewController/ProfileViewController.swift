//
//  ProfileViewController.swift
//  PhycomincTest
//
//  Created by Rohit on 04/05/24.
//

import UIKit

class ProfileViewController: UIViewController {

    // MARK: - IBOutlet's
    @IBOutlet weak var tblView: UITableView!
    
    // MARK: - Variable's
    var profileArray = ["Update Profile","Sign Out"]
    var imgArray = ["Profile","Logout"]
    
    // MARK: - Lifcycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = Constant.NavigationTitle.profile
        self.tableConfiguration()
    }

    // MARK: - Custom Method's
    func tableConfiguration() {
        self.tblView.delegate = self
        self.tblView.dataSource = self
        // self.tblView.separatorStyle = .none
        self.tblView.register(UINib(nibName: Constant.CellIdentifiers.profileCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifiers.profileCell)
    }

    func updateProfile() {
        let mainStoryBoard: UIStoryboard = UIStoryboard(name: Constant.StoryboardIdentifier.main, bundle: nil)
        let updateProfileVC = mainStoryBoard.instantiateViewController(withIdentifier: Constant.ViewControllerIdentifiers.updateProfileVC) as? UpdateProfileViewController
         self.navigationController?.pushViewController(updateProfileVC!, animated: true)
    }
    
    func signOut() {
        showAlert(title: "Logout", message: "Do you want to logout?", okHandler: {
            Utils.sharedUtils.deinitUserDefaultsAndSignOut { isSignOut in
                if isSignOut {
                    let mainStoryBoard: UIStoryboard = UIStoryboard(name: Constant.StoryboardIdentifier.main, bundle: nil)
                    let loginVC = mainStoryBoard.instantiateViewController(withIdentifier: Constant.ViewControllerIdentifiers.viewController)
                    UIApplication.shared.windows.first?.rootViewController = loginVC
                }
            }
        }, cancelHandler: {
            self.dismiss(animated: true)
        })
    }
    
    func showAlert(title: String, message: String, okHandler: (() -> Void)? = nil, cancelHandler: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Yes", style: .default) { _ in
            okHandler?()
        }
        alertController.addAction(okAction)
        
        let cancelAction = UIAlertAction(title: "No", style: .cancel) { _ in
            cancelHandler?()
        }
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }

}

// MARK: - Tableview Deatasource and Delegate
extension ProfileViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return profileArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifiers.profileCell) as? ProfileCell
        cell?.selectionStyle = .none
        
        cell?.lbl_title.text = profileArray[indexPath.row]
        cell?.img_icon.image = UIImage(named: imgArray[indexPath.row])
        
        return cell ?? UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            self.updateProfile()
        case 1:
            self.signOut()
        default:
            break
        }
    }
    
}
