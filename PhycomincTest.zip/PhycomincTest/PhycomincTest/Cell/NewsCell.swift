//
//  NewsCell.swift
//  PhycomincTest
//
//  Created by Rohit on 04/05/24.
//

import UIKit
import SDWebImage

class NewsCell: UITableViewCell {
    
    // MARK: - IBOutlet's
    @IBOutlet weak var img: UIImageView! {
        didSet {
            self.img.layer.cornerRadius = 4
            self.img.contentMode = .scaleAspectFill
        }
    }
    @IBOutlet weak var lbl_author: UILabel!
    @IBOutlet weak var lbl_title: UILabel!
    @IBOutlet weak var lbl_date: UILabel!
    @IBOutlet weak var mainView: UIView! {
        didSet {
            // self.mainView.layer.borderWidth = 0.5
            self.mainView.layer.borderColor = UIColor.black.cgColor
            self.mainView.layer.cornerRadius = 4
            self.mainView.layer.shadowOpacity = 1
            self.mainView.layer.shadowOffset = .zero
            self.mainView.layer.shadowRadius = 2
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
    // MARK: - Configuration of the Table
    func configuration(data : Articles) {
        
        let dateStringFromDatabase = data.publishedAt ?? ""
        let formattedDate = Utils.sharedUtils.formatDatabaseDateString(dateStringFromDatabase)
        
        self.lbl_date.text = formattedDate
        
        if let url = URL(string: data.urlToImage ?? "") {
            self.img.sd_setImage(with: url, completed: nil)
        } else {
            self.img.image = UIImage(named: "NoImage")
        }
        self.lbl_author.text = data.author
        self.lbl_title.text = data.title
    }
    
}
