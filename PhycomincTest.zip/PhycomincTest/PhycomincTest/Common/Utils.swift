//
//  Utils.swift
//  PhycomincTest
//
//  Created by Rohit on 03/05/24.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import GoogleSignIn

class Utils {
    
    static let sharedUtils = Utils()
    
    var userDefault = Foundation.UserDefaults.standard
    
    func loginUser(email: String, password: String) {
        
        // guard let clientID = FirebaseApp.app()?.options.clientID else { return }
        let config = GIDConfiguration(clientID: Constant.Key.clientID)
        GIDSignIn.sharedInstance.configuration = config
        
        Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
            if let error = error {
                print("Error logging in: \(error.localizedDescription)")
                // Handle error
                return
            }
            
            guard let user = result?.user else {
                print("No user found")
                // Handle no user found
                return
            }
            
            print("User logged in with ID: \(user.uid)")
            // Handle successful login, such as navigating to the next screen
        }
    }
    
    func googleSignIn(ViewController : UIViewController, completion: @escaping (Bool) -> Void) {
        GIDSignIn.sharedInstance.signIn(withPresenting: ViewController) { [unowned self] result, error in
            guard error == nil else {
                return
            }
            
            guard let user = result?.user,
                  let idToken = user.idToken?.tokenString
            else {
                return
            }
            
            let credential = GoogleAuthProvider.credential(withIDToken: idToken,
                                                           accessToken: user.accessToken.tokenString)
            Auth.auth().signIn(with: credential) { result, error in
                print("User successfully login...")
                
                let username = result?.user.email ?? ""
                let displayName = result?.user.displayName ?? ""
                let photoURL = result?.user.photoURL?.absoluteString ?? ""
                
                self.userDefault.set(username, forKey: "userName")
                self.userDefault.set(displayName, forKey: "displayName")
                self.userDefault.set(photoURL, forKey: "photoURL")
                print("Username : \(username)")
                print("Display Name : \(displayName)")
                print("PhotoURL : \(photoURL)")
                
                completion(true)
                
            }
            
        }
    }
    
    func saveNewsDataToFile(newsData: NewsData) {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = documentsDirectory.appendingPathComponent("newsData.json")
        
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(newsData)
            try data.write(to: fileURL)
            print("News data saved to file: \(fileURL.path)")
        } catch {
            print("Error saving news data: \(error)")
        }
    }
    
    
    func deinitUserDefaultsAndSignOut(completion: @escaping (Bool) -> Void) {
        self.userDefault.removeObject(forKey: "userName")
        self.userDefault.removeObject(forKey: "displayName")
        self.userDefault.removeObject(forKey: "photoURL")
        
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
            print("User has Signing Out")
            completion(true)
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
    }
    
    
    //    func updateUserProfile(displayName : String, photoURL: URL) {
    //        let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
    //        changeRequest?.photoURL = photoURL
    //        changeRequest?.displayName = displayName
    //        changeRequest?.commitChanges(completion: { (error) in
    //            if let error = error {
    //                print(error.localizedDescription)
    //                // self.view.makeToast(error.localizedDescription)
    //            }
    //        })
    //    }
    
    
    func updateUserProfile(displayName: String?, photoURL: URL?, email: String?) {
        let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
        
        if let displayName = displayName {
            changeRequest?.displayName = displayName
        }
        
        if let photoURL = photoURL {
            changeRequest?.photoURL = photoURL
        }
        
        if let email = email {
            Auth.auth().currentUser?.updateEmail(to: email) { error in
                if let error = error {
                    print(error.localizedDescription)
                    // Handle error updating email
                    return
                }
                print("Email updated successfully")
            }
        }
        
        changeRequest?.commitChanges { error in
            if let error = error {
                print(error.localizedDescription)
                // Handle error committing changes
                return
            }
            print("Profile updated successfully")
        }
    }
    
    func formatDatabaseDateString(_ dateString: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZZZZZ"
        
        if let date = dateFormatter.date(from: dateString) {
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = "d'\(daySuffix(from: date))' MMM, yyyy hh:mm a"
            return outputFormatter.string(from: date)
        } else {
            return "Invalid date string"
        }
    }
    
    func daySuffix(from date: Date) -> String {
        let calendar = Calendar.current
        let dayOfMonth = calendar.component(.day, from: date)
        switch dayOfMonth {
        case 1, 21, 31: return "st"
        case 2, 22: return "nd"
        case 3, 23: return "rd"
        default: return "th"
        }
    }
    
}
