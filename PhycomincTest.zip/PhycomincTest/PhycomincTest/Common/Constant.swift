//
//  Constant.swift
//  PhycomincTest
//
//  Created by Rohit on 03/05/24.
//

import Foundation

struct Constant {

    struct CellIdentifiers {
        static let newsCell = "NewsCell"
        static let profileCell = "ProfileCell"
    }
    
    struct NavigationTitle {
        static let profile = "Profile"
        static let newsList = "News List"
        static let webView = "Web View"
        static let newsDetail = "News Detail"
    }
    
    struct StoryboardIdentifier {
        static let main = "Main"
    }
    
    struct ViewControllerIdentifiers {
        static let tabBarVC = "TabBarViewController"
        static let newsListVC = "NewsListViewController"
        static let newsDetailVC = "NewsDetailViewController"
        static let viewController = "ViewController"
        static let updateProfileVC = "UpdateProfileViewController"
        static let WKWebVC = "WKWebViewController"
        static let fullScreenImageVC = "FullScreenImageViewController"
    }
    
    struct Key {
        static let API_KEY = "03cb6214e1df44799f15afc5d7cb19b8"
        static let url = "https://newsapi.org/v2/top-headlines?country=us&apiKey="
        static let clientID = "221830975756-lh9g4gc4mboo97pfpah4kfkgtdmensqo.apps.googleusercontent.com"
    }
}
