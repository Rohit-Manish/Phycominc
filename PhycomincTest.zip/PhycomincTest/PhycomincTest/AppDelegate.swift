//
//  AppDelegate.swift
//  PhycomincTest
//
//  Created by Rohit on 03/05/24.
//

import UIKit
import CoreData
import FirebaseCore
import FirebaseAuth
import GoogleSignIn

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    public static var shared = AppDelegate()
    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        FirebaseApp.configure()
        let config = GIDConfiguration(clientID: Constant.Key.clientID)
        GIDSignIn.sharedInstance.configuration = config
        
        let user = Auth.auth().currentUser
        if (user == nil) {
            let mainStoryBoard: UIStoryboard = UIStoryboard(name: Constant.StoryboardIdentifier.main, bundle: nil)
            let loginVC = mainStoryBoard.instantiateViewController(withIdentifier: Constant.ViewControllerIdentifiers.viewController) as! ViewController
            window!.rootViewController = loginVC
            window!.makeKeyAndVisible()
        } else {
            let mainStoryBoard: UIStoryboard = UIStoryboard(name: Constant.StoryboardIdentifier.main, bundle: nil)
            let tabBarVC = mainStoryBoard.instantiateViewController(withIdentifier: Constant.ViewControllerIdentifiers.tabBarVC) as? TabBarViewController
            window!.makeKeyAndVisible()
            window!.rootViewController = tabBarVC
        }
        
        return true
    }
    
    // MARK: - Core Data stack
    lazy var persistentContainer: NSPersistentContainer = {
        
        let container = NSPersistentContainer(name: "PhycomincTest")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    // MARK: - Core Data Saving support
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

}
